# Training Philosophy and Assessment Model

## Training population

- Residential students approximately 19–20 years old.
- Generally second- or third-year SVNIT students.
- Approximately one year of prior Krishna consciousness practice.
- Attend college while living as full-time residents.
- Primary preaching language: Hindi.
- Expected residential development period: approximately two years.

## Common platform with individual application

Every student should receive exposure in all essential areas. Individual aptitude, health, confidence, maturity, academic load, and devotional inclination should affect the pace and method of training, but should not remove the minimum exposure expected from the institution.

Students may later specialize according to their nature. Specialization must not become an excuse for neglecting foundational character, sadhana, preaching relationships, teamwork, or basic practical competence.

## Three separate assessment dimensions

### 1. Foundational spiritual health

These areas are prerequisites for sustained responsibility:

- Sadhana quality and spiritual absorption.
- Timely sleep and a dependable morning routine.
- Purity.
- Honesty and openness with the FOLK guide.
- Vaishnava etiquette and conduct.
- Willingness to serve.

Phone regulation and academic responsibility are important supporting areas. They should be monitored carefully because they can strengthen or destabilize the foundations.

### 2. Functional missionary competence

- Preaching and follow-up.
- Newcomer and junior care.
- Philosophy explained simply and accurately.
- Public speaking and discussion facilitation.
- Storytelling.
- Kirtan, singing, mrdanga, karatalas, and basic harmonium.
- Basic deity worship and understanding of prayers.
- Prasadam honoring and serving etiquette.
- Event and festival organization.
- Trip planning and execution.
- Permissions, budgeting, transport, accommodation, publicity, volunteer coordination, and reporting.
- Teamwork, delegation, administration, and mentoring.

### 3. Missionary disposition

- Notices needs without repeated prompting.
- Feels concern for Srila Prabhupada's mission.
- Thinks about organizational and preaching improvement.
- Accepts responsibility and follows through.
- Seeks guidance without becoming passive.
- Remains transparent while exercising initiative.
- Cares for people rather than merely completing tasks.
- Cooperates with seniors, equals, and juniors.
- Receives correction without defensiveness.
- Learns from difficulty and tries again.
- Helps develop future servants and leaders.

## Daily-life context

The expected weekday rhythm includes waking before mangala-arati, morning program, attentive chanting, Bhagavatam class, prasadam, college, completion of pending rounds, at least one hour of reading, academic study, and preaching service.

Late sleeping is a recurring systemic risk. It can delay waking and chanting, consume preaching and personal time, push academic work late into the night, and create a repeating cycle. The CRM should therefore record patterns and causes, not simply isolated late mornings.

## Evaluation principles

- Evaluate conduct and demonstrated service, not merely attendance.
- Treat personal conversation as essential evidence.
- Distinguish sincere struggle from careless neglect.
- Sincere struggle usually includes openness, seeking guidance, effort, and willingness to accept help.
- Carelessness is reflected in an indifferent attitude, repeated concealment, refusal of guidance, or damage to the residential environment.
- Address failures privately through personal guidance, never through public humiliation.
- Do not confuse musical, speaking, or organizational talent with spiritual maturity.
- Do not assign greater authority merely because someone is charismatic or technically capable.
- Record specific observations rather than labels about personality or spiritual worth.

## Existing systems outside this module

Detailed book-study tracking is maintained separately. This CRM may link to that tracker but should not duplicate it. Relevant outcomes include:

- Memorization of the selected 108 Bhagavad-gita verses, translations, and assigned purports.
- Memorization and understanding of essential Vaishnava songs and prayers.
- Sufficient understanding of Srila Prabhupada's books to explain fundamental Krishna consciousness concepts simply, even to a child.
