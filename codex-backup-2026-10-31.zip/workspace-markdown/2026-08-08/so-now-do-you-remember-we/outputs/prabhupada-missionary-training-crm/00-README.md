# Prabhupada Missionary Training CRM Specification

## Purpose

This package specifies a CRM module for developing residential college students into spiritually grounded, dependable, self-driven, full-time missionaries dedicated to Srila Prabhupada's mission.

The CRM is not intended to replace the personal judgment or relationship of the FOLK guide. It should preserve contextual memory, organize observations, reveal development patterns, and help the guide decide the next appropriate training step.

## Core outcome

After approximately two years of residential training, each student should:

- Maintain strong, attentive sadhana and a disciplined daily routine.
- Demonstrate purity, honesty, openness, Vaishnava etiquette, and willingness to serve.
- Think independently about how to advance the mission while remaining transparent and guided.
- Receive exposure to every essential missionary competency.
- Become competent in preaching, newcomer care, public speaking, kirtan support, event execution, teamwork, and administration.
- Accept responsibility without requiring repeated reminders.
- Care for juniors and help connect them deeply with the FOLK guide.
- Be capable of training and empowering others in areas in which he has matured.

## Guiding principle

> Self-driven does not mean independent of guidance. A mature student notices needs, proposes and performs service, reports honestly, seeks guidance at the appropriate time, cooperates with devotees, and acts in the mood of servant of the servant.

## Documents

1. `01-training-philosophy.md` — foundations, developmental competencies, and evaluation principles.
2. `02-competency-dictionary.md` — standard CRM competency categories and proficiency scale.
3. `03-crm-data-model.md` — entities, fields, relationships, permissions, and history requirements.
4. `04-mentoring-workflows.md` — weekly meetings, monthly reviews, service assignments, and advancement.
5. `05-relationship-management.md` — newcomer care, authority boundaries, follow-up, and escalation.
6. `06-contextual-intelligence-and-privacy.md` — AI-assisted contextual memory, privacy, and safety guardrails.
7. `07-trello-integration.md` — immediate Trello workflow and eventual CRM integration.

## Implementation order

1. Create student profiles and access controls.
2. Add weekly mentoring records.
3. Add monthly development plans and practical service assignments.
4. Add versioned competency assessments and evidence.
5. Add preaching relationships and follow-up.
6. Import selected Trello data.
7. Add contextual summaries and mentor-facing suggestions only after the underlying records are reliable.

## Important product decision

Do not calculate one overall score for a student. Display foundational spiritual health, functional missionary competence, and missionary disposition separately. A single score can hide serious foundational concerns behind visible skills or activity.
