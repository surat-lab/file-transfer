# Relationship Management and Newcomer Care

## Purpose

A student caretaker should become a cordial and dependable bridge between a newcomer and the FOLK guide. His role is relational and supportive, not controlling.

## Care sequence

> Connect → understand → care → guide appropriately → follow up → connect with the FOLK guide → report relevant needs

## Expected behaviors

- Break the ice naturally and respectfully.
- Learn the person's name, situation, interests, and immediate concerns.
- Listen more carefully than he speaks.
- Make the newcomer feel welcome without creating dependency.
- Invite him to the most suitable next program.
- Follow up personally rather than sending only generic messages.
- Give basic Krishna consciousness guidance within his maturity and training.
- Admit when he does not know.
- Help the newcomer feel free to speak directly with the FOLK guide.
- Communicate significant difficulties or needs to the guide discreetly.
- Maintain appropriate gravity and boundaries.
- Remember that relationship quality matters more than contact counts alone.

## Authority boundary

The student caretaker may:

- Explain basic philosophy and practices.
- Encourage attendance, chanting, reading, and good association.
- Listen to ordinary difficulties.
- Share approved resources.
- Offer practical help within defined limits.
- Arrange a conversation with the FOLK guide.

The student caretaker may not independently:

- Direct major educational, career, financial, family, medical, psychological, legal, residential, or life decisions.
- Claim spiritual authority beyond his role.
- Demand disclosure of intimate information.
- Promise confidentiality that prevents necessary escalation.
- Use pressure, fear, guilt, manipulation, or social isolation.
- Handle serious safeguarding, self-harm, abuse, addiction, or medical situations without appropriate senior and professional involvement.

## Follow-up stages

Suggested CRM stages:

1. New contact
2. Invited
3. Attended once
4. Exploring regularly
5. Beginning practice
6. Connected with FOLK guide
7. Receiving structured care
8. Temporarily inactive
9. No further contact requested

These stages describe engagement, not spiritual worth.

## Relationship-quality indicators

- Follow-up is timely and personalized.
- The newcomer feels heard and respected.
- Commitments are not exaggerated.
- The caretaker remembers relevant context.
- The newcomer becomes connected to the wider devotee community and guide, not dependent on one student.
- Difficulties are escalated at the appropriate time.
- The caretaker remains stable in his own sadhana and boundaries.

## Suggested review questions

- What does this person currently need?
- What did he actually express, and what are we merely assuming?
- What is the next natural step rather than the largest possible step?
- Is the caretaker acting within his maturity and authority?
- Has the person been appropriately connected with the FOLK guide?
- Is follow-up compassionate, or has it become mechanical and target-driven?
