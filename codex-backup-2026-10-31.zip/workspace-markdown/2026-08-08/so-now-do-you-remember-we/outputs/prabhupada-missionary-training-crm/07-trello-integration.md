# Trello Workflow and CRM Integration

## Trello's immediate role

Use Trello for current operational work:

- Weekly meeting due dates.
- Monthly review status.
- Active development priorities.
- Practical service assignments.
- Event tasks.
- Follow-up reminders.

Do not use a broadly shared Trello board as the permanent store for sensitive mentoring information.

## Suggested private board lists

1. Students to review
2. Weekly meeting due
3. Priority action required
4. Development plan active
5. Service assignment in progress
6. Review completed this month
7. Temporarily paused or unavailable
8. Archive

## Student card structure

Maintain one permanent card per student containing:

- Student name, academic year, and development stage.
- Assigned FOLK guide.
- Current strengths and growth areas.
- Present preaching and service responsibilities.
- Current monthly priorities.
- Next meeting and review dates.
- Link to the CRM student profile when available.

Use labels for attention areas, not judgments about personality:

- Foundation needs attention
- Stable foundation
- Preaching development
- Leadership development
- Kirtan development
- Event or administration development
- Academic pressure
- Guide attention required

## Weekly Trello template

- Date
- Current condition
- Previous commitment status
- Sadhana and routine observation
- Service and preaching update
- Principal difficulty
- Guidance given
- Student commitment
- Guide follow-up
- Next meeting date

Sensitive details should be stored in a restricted CRM record or private mentor system. Trello may contain only: `Private mentoring follow-up required`.

## Monthly Trello template

- Foundational health summary
- Strongest improvement
- Principal concern
- Three priorities
- One practical service assignment
- Support required
- Student-facing summary prepared
- Next review date

## Integration direction

The intended flow is:

1. CRM stores the authoritative student profile, history, assessment evidence, and restricted notes.
2. Approved priorities and assignments are sent to Trello for execution.
3. Trello tracks deadlines, checklists, ownership, and completion.
4. Completion evidence and the mentor's debrief return to the CRM.
5. The CRM uses the returned evidence in future reviews.

Avoid two-way free-text synchronization. It can duplicate private information and create conflicting records.

## Suggested synchronization keys

- `crm_student_id`
- `crm_assignment_id`
- `trello_board_id`
- `trello_card_id`
- `trello_checklist_item_id`
- `last_synced_at`
- `sync_status`

## Import sequence

1. Export or read the existing Trello board.
2. Match each student card to one CRM student.
3. Import stable profile data after mentor verification.
4. Import only useful historical milestones and evidence.
5. Do not automatically import sensitive comments into ordinary CRM fields.
6. Place unclassified comments in a restricted review queue.
7. Let the assigned guide approve, edit, classify, or discard each sensitive historical item.

## Long-term division of responsibility

| System | Primary responsibility |
|---|---|
| CRM | Context, history, mentoring, assessments, evidence, permissions, and development decisions |
| Trello | Immediate tasks, deadlines, event execution, checklists, and operational coordination |
| Book tracker | Detailed reading, memorization, and curriculum progress |

The CRM should link these systems around the student without copying every detail into one large unstructured record.
