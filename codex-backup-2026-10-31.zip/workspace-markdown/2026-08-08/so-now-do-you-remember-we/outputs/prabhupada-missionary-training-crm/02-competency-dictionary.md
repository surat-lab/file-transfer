# Competency Dictionary

## Universal proficiency scale

Every competency uses the same five levels:

| Level | Name | Meaning |
|---|---|---|
| 0 | Not introduced | No structured exposure has yet been provided. |
| 1 | Introduced | Has received explanation or demonstration and understands the basic expectation. |
| 2 | Practising under guidance | Performs with supervision, reminders, correction, or assistance. |
| 3 | Independently competent | Performs dependably in real service without repeated reminders while remaining transparent. |
| 4 | Able to train others | Performs maturely, diagnoses common difficulties, and develops another student under senior guidance. |

A rating must contain dated evidence. Time spent, attendance, confidence, or self-description alone is insufficient.

## A. Sadhana and spiritual foundations

### A1. Morning-program dependability

Wakes before mangala-arati, attends attentively, and protects the morning program through responsible nighttime habits.

### A2. Japa quality

Chants prescribed rounds while hearing each mantra and consciously attempting absorption. Assessment should include quality, struggle, effort, and recovery—not completion alone.

### A3. Hearing and reading discipline

Participates attentively in Bhagavatam class and maintains the expected daily reading practice. Detailed book completion remains in the separate book tracker.

### A4. Timely sleep and routine protection

Plans college, preaching, reading, and academic work so that late nights do not repeatedly damage morning sadhana.

### A5. Purity and honest help-seeking

Maintains expected standards and approaches the guide honestly when struggling with sexual temptation, pornography, secrecy, or related difficulties.

### A6. Openness with the FOLK guide

Reveals relevant concerns, receives guidance, reports truthfully, and does not construct a misleading picture of his condition.

## B. Vaishnava character and personal discipline

### B1. Vaishnava etiquette

Deals respectfully and appropriately with seniors, equals, and juniors; avoids familiarity, contempt, gossip, humiliation, and misuse of authority.

### B2. Servant attitude

Accepts visible and invisible services, assists others, and works in the mood of dasa-dasa-dasanudasa.

### B3. Cleanliness and residential responsibility

Maintains personal and shared spaces and contributes to a clean devotional environment without repeated reminders.

### B4. Prasadam consciousness

Offers prayers, honors prasadam mindfully, avoids unnecessary chit-chat, and serves others attentively and respectfully.

### B5. Phone and digital discipline

Uses the phone purposefully, follows agreed boundaries, avoids compulsive use, and honestly seeks help when usage becomes destabilizing.

### B6. Emotional maturity

Handles discouragement, correction, conflict, disappointment, and temptation through philosophy, prayer, dialogue, and responsible action.

### B7. Planning and time management

Plans sadhana, college, academics, reading, preaching, service, health, and sleep in a realistic manner.

### B8. Academic responsibility

Maintains responsible college participation without using academics to abandon devotional commitments or using service to neglect legitimate academic duties.

## C. Philosophy and communication

### C1. Fundamental philosophy

Explains foundational Krishna consciousness topics confidently, faithfully, and in simple language.

### C2. Discussion facilitation

Leads Read–Discuss–Understand–Analyze sessions, invites participation, keeps discussion focused, and concludes with clear understanding and application.

### C3. Short talks and classes

Delivers short talks, structured classes, and online sessions using supplied materials while understanding rather than parroting them.

### C4. Storytelling

Uses relevant stories with accurate meaning, appropriate emotion, clear structure, and connection to the teaching point.

### C5. Questions and answers

Answers within his knowledge, admits uncertainty, avoids speculation, and refers deeper questions appropriately.

### C6. Cordial personal communication

Speaks gently, listens carefully, respects boundaries, understands the other person's needs, and follows up reliably.

## D. Preaching and relationship care

### D1. Contacting new students

Approaches or contacts friends, seniors, juniors, first-year students, M.Tech students, and PhD students respectfully and naturally.

### D2. One-to-one preaching

Understands the student's situation, shares relevant Krishna consciousness, listens, and recommends an appropriate next step.

### D3. Follow-up discipline

Maintains timely, personal, non-mechanical follow-up and records the next agreed action.

### D4. Program invitation and connection

Connects students with Friday Kirtan Night, Sadhakas, home programs, online classes, campus programs, and other suitable association.

### D5. Newcomer care

Acts as an icebreaker, creates trust, understands difficulties, gives basic appropriate guidance, and connects the newcomer freely with the FOLK guide.

### D6. Junior care

Shows compassion, models practice, maintains contact, supports the junior, and communicates important needs to the guide.

### D7. Book distribution

Participates in and eventually performs respectful, thoughtful book distribution according to organizational guidance.

### D8. Home and campus programs

Assists with and eventually coordinates invitations, logistics, hospitality, participation, follow-up, and reporting.

## E. Kirtan and devotional practical skills

### E1. Karatalas

Maintains appropriate rhythm, volume, attention, and cooperation with the kirtan leader.

### E2. Mrdanga

Learns foundational rhythms and supports kirtan steadily without overpowering the devotional mood.

### E3. Basic harmonium

Understands basic notes, chords or melodic support sufficient for guided practice and simple devotional singing.

### E4. Singing and kirtan support

Sings prayers and responses with correct words, attentive mood, appropriate pitch, volume, and cooperation.

### E5. Kirtan leading

Where aptitude permits, leads appropriately; otherwise becomes a dependable supporting singer or instrumentalist. Musical performance must not overshadow devotion or cooperation.

### E6. Prayers and meanings

Recites fundamental prayers and explains their essential meanings.

### E7. Basic deity worship

Knows and follows the locally authorized basic standards of cleanliness, respect, preparation, and service.

### E8. Festival service initiative

Identifies festival-centered campus opportunities and helps plan services that connect students with Krishna consciousness.

## F. Events, trips, and administration

### F1. Event planning

Defines purpose, audience, date, venue, program flow, responsibilities, resources, risk, and follow-up.

### F2. Budgeting and financial responsibility

Prepares estimates, obtains authorization, maintains records, handles funds transparently, and reports actual expenses.

### F3. Permissions and stakeholder coordination

Communicates professionally with college authorities, venue contacts, volunteers, and responsible seniors.

### F4. Transport and accommodation

Plans movement, lodging, attendance, schedules, contingencies, and student welfare.

### F5. Publicity and registration

Coordinates invitations, approved publicity, registration, reminders, and attendance information.

### F6. Volunteer coordination

Allocates roles, confirms understanding, follows up without harshness, appreciates service, and resolves gaps.

### F7. Event execution

Maintains time, responds to changing circumstances, communicates with the guide, and protects participant experience.

### F8. Post-event review

Records outcomes, contacts, follow-up, expenses, lessons, unresolved issues, and improvements for the next event.

## G. Leadership and missionary disposition

### G1. Dependability

Completes accepted responsibilities, communicates early when blocked, and does not require repeated chasing.

### G2. Guided initiative

Notices needs, thinks through possible action, consults at the appropriate level, acts, and reports results.

### G3. Teamwork

Cooperates, shares credit, communicates respectfully, supports team decisions, and helps others succeed.

### G4. Receiving and applying guidance

Listens without superficial agreement, asks clarifying questions, applies guidance, and reports honestly on the result.

### G5. Mentoring juniors

Models conduct, supports development, stays within authority, and mentors under the FOLK guide's supervision.

### G6. Organizational thoughtfulness

Recognizes preaching or operational challenges, gathers facts, proposes practical improvements, and considers effects on people and mission.

### G7. Training others

Breaks a skill into learnable steps, demonstrates it, observes practice, gives respectful feedback, and reports development to the responsible senior.
