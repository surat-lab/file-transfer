# Contextual Intelligence, Privacy, and Safety

## Role of contextual intelligence

The CRM may use historical records to help the FOLK guide remember context, identify patterns, prepare questions, and select suitable training assignments.

It must not replace personal association, make spiritual judgments, or automatically decide a student's readiness, sincerity, purity, or future.

## Appropriate system outputs

The system may produce:

- A timeline of meetings, commitments, and service assignments.
- Changes in competency ratings with cited evidence.
- Unfinished follow-up items.
- Repeated patterns that are directly supported by records.
- Questions the guide may consider asking.
- Possible assignments connected to agreed development priorities.
- A draft monthly summary for guide review.

Examples of appropriately worded patterns:

- "Three records this month mention sleeping after the agreed time, followed by delayed morning chanting. The guide may wish to explore academic scheduling and nighttime phone use."
- "The student completed two public-facing assignments but required repeated reminders for internal team coordination. Consider a smaller assignment emphasizing dependability and communication."

## Prohibited or unsafe outputs

The system should not:

- Declare that a student is spiritually advanced, fallen, insincere, or unfit.
- Infer pornography use, mental illness, sexual behavior, or concealed misconduct without an explicit and authorized source record.
- Diagnose medical or psychological conditions.
- Recommend punishment automatically.
- Rank students publicly.
- expose one student's confidential information to another.
- Present an AI inference as a fact.
- use private mentoring information for publicity, fundraising, or unrelated organizational decisions.

## Information classification

### Operational

Programs attended, service assignments, scheduling, competencies, and ordinary follow-up.

### Mentor confidential

Personal struggles, family matters, emotional condition, private guidance, interpersonal conflicts, and sensitive academic concerns.

### Highly restricted

Sexual or pornography-related disclosures, self-harm or safety concerns, abuse allegations, medical information, legal matters, and serious misconduct.

Highly restricted information should be minimized, encrypted where supported, access logged, and visible only to explicitly authorized persons.

## Note-writing standard

- Record only what is necessary to provide care.
- Prefer behavior and context over labels.
- Identify the source: student statement, guide observation, third-party report, or system inference.
- Avoid speculative motives.
- Avoid humiliating language.
- Correct inaccurate records when discovered while preserving an audit trail.
- Define a retention and deletion policy rather than keeping every sensitive detail forever.

## Human review requirements

The FOLK guide must review and approve:

- Monthly summaries.
- Suggested development priorities.
- Competency advancement.
- Foundation concern flags.
- Any student-facing summary generated from private records.

The student should receive guidance and agreed actions in human language. He should not be confronted with an unexplained machine-generated risk label.

## Access and accountability

- Apply least-privilege access.
- Log access to confidential records.
- Show the author and timestamp of every note.
- Maintain amendment history.
- Prevent bulk export of sensitive records except by specifically authorized administrators.
- Back up data securely.
- Establish what happens to records when a student leaves the residence.

## Context summary prompt contract

Any future AI component should be instructed to:

1. Cite the dated CRM records supporting each observation.
2. Separate facts, mentor observations, student statements, and inferences.
3. State uncertainty.
4. Avoid diagnosis and spiritual judgment.
5. Suggest questions rather than assert hidden motives.
6. Recommend proportionate, observable next steps.
7. Respect role-based visibility and confidentiality.
