# Mentoring and Development Workflows

## Weekly mentoring workflow

### Before the meeting

The CRM prepares a concise guide-only brief:

- Previous commitment and whether it was completed.
- Current monthly priorities.
- Recent service assignments.
- Recent competency evidence.
- Missed or delayed routines, if recorded.
- Preaching relationships needing follow-up.
- Open questions from the previous meeting.

### During the meeting

The guide should understand the person rather than mechanically complete fields. Suggested sequence:

1. Current condition and significant events.
2. Quality of sadhana and morning absorption.
3. Sleep and the practical causes of any disruption.
4. Purity, phone use, and honest struggles where relevant.
5. Relationships with seniors, equals, juniors, parents, and classmates.
6. College responsibilities and personal ambitions.
7. Current service and preaching relationships.
8. Initiative, dependability, and willingness to serve.
9. One principal difficulty needing guidance.
10. A realistic commitment before the next meeting.

### After the meeting

- Record only relevant, factual, and proportionate notes.
- Record guidance and commitments distinctly.
- Schedule follow-up.
- Update the active development plan only when appropriate.
- Create an urgent follow-up only if actual risk or serious misconduct requires it.

## Monthly development review

The FOLK guide completes the rating. The student does not assign his own proficiency score.

Required outputs:

- Private detailed mentor assessment.
- Short student-facing development summary.
- Three priorities for the coming month.
- One principal practical service assignment.
- Support required from the guide or another trainer.
- Date of the next review.

The review should compare the student primarily with his previous condition and agreed standard, not competitively with other students.

## Practical assignment design

A good assignment contains:

- A concrete outcome.
- A clear deadline.
- The authority the student does and does not have.
- The senior or peer providing support.
- The competency being developed.
- Observable evidence of completion.
- A debrief after completion.

Examples:

- Reconnect with three inactive students, understand their present needs, and propose appropriate follow-up.
- Lead a 15-minute online discussion using approved material and review the recording with a mentor.
- Assist Friday Kirtan Night and independently coordinate volunteer allocation under the program lead.
- Care for one newcomer for a month, help him feel comfortable, and facilitate his connection with the FOLK guide.
- Prepare the plan, permissions checklist, transport arrangement, and budget estimate for a supervised trip.

## Development progression

### Stage 1: Foundation

- Protects sadhana and sleep with active guidance.
- Learns Vaishnava etiquette and residential responsibility.
- Performs small services reliably.
- Receives correction and reports honestly.
- Receives basic exposure to preaching, speaking, music, and events.

### Stage 2: Guided practice

- Maintains regular follow-up with selected students.
- Leads small parts of programs or discussions.
- Takes supervised event and administrative responsibility.
- Develops basic kirtan support competence.
- Begins planning his week and reporting results.

### Stage 3: Independent competence

- Maintains assigned services without repeated reminders.
- Manages defined preaching relationships and programs.
- Organizes events or trip components with appropriate consultation.
- Communicates early when blocked.
- Remains transparent and cooperative while exercising initiative.

### Stage 4: Multiplication

- Trains juniors in demonstrated competencies.
- Develops new caretakers and team members.
- Notices organizational needs and proposes well-considered solutions.
- Can lead a defined initiative under senior oversight.
- Protects culture, relationships, and devotional purpose while pursuing results.

Advancement is based on stable foundations and demonstrated evidence, not time elapsed, popularity, charisma, or isolated success.

## Foundation concern workflow

When a foundational area is unstable:

1. Record the specific observed pattern.
2. Discuss privately and understand the underlying cause.
3. Agree on a small corrective plan.
4. Increase meeting frequency if useful.
5. Reduce or reshape visible responsibility when necessary for the student's welfare and the community.
6. Review whether the student is sincerely struggling or displaying persistent indifference and concealment.
7. Involve the appropriate senior authority for serious, repeated, or safety-related concerns.

Do not publicly shame the student or expose confidential struggles.
