# CRM Data Model

## Design requirements

- Preserve history; do not overwrite past assessments or mentoring records.
- Separate objective facts, mentor observations, student statements, and system-generated suggestions.
- Apply field-level or record-level access control to sensitive information.
- Require evidence for proficiency changes.
- Allow links to external book-study tracking without duplicating it.
- Support import from Trello without making Trello the permanent source of truth.

## Entity 1: Student

Required fields:

- `student_id`
- `full_name`
- `college`
- `department`
- `academic_year`
- `primary_language`
- `residency_start_date`
- `assigned_guide_id`
- `current_development_stage`
- `mentoring_frequency`
- `active_status`
- `next_weekly_meeting_date`
- `next_monthly_review_date`

Optional controlled fields:

- Natural strengths
- Current growth areas
- Health or schedule accommodations
- Current preaching responsibility
- Current organizational responsibility
- Current juniors or newcomers under care
- Book-tracker reference
- Trello card reference

## Entity 2: Mentoring meeting

- `meeting_id`
- `student_id`
- `guide_id`
- `meeting_date`
- `meeting_type`: weekly, fortnightly, monthly, urgent, other
- `current_condition_summary`
- `sadhana_observation`
- `sleep_and_routine_observation`
- `openness_and_honesty_observation`
- `vaishnava_relationship_observation`
- `college_and_academic_context`
- `service_and_preaching_context`
- `difficulty_discussed`
- `guidance_given`
- `student_commitment`
- `guide_commitment`
- `follow_up_date`
- `confidentiality_level`
- `created_by`
- `created_at`

The meeting record must distinguish direct student statements from mentor interpretation.

## Entity 3: Competency definition

- `competency_id`
- `category`
- `name`
- `definition`
- `foundational_or_developmental`
- `level_0_definition`
- `level_1_definition`
- `level_2_definition`
- `level_3_definition`
- `level_4_definition`
- `acceptable_evidence_examples`
- `active_status`
- `version`

## Entity 4: Competency assessment

- `assessment_id`
- `student_id`
- `competency_id`
- `level`
- `assessment_date`
- `assessed_by`
- `evidence_summary`
- `linked_service_assignment_id`
- `strength_observed`
- `next_development_step`
- `reassessment_date`
- `confidence`: low, medium, high

Never update an assessment in place after it has been finalized. Create a new assessment so progression and regression remain visible.

## Entity 5: Monthly development plan

- `plan_id`
- `student_id`
- `month`
- `guide_id`
- `foundational_health_summary`
- `functional_competence_summary`
- `missionary_disposition_summary`
- `principal_improvement`
- `principal_concern`
- `priority_1`
- `priority_2`
- `priority_3`
- `principal_service_assignment_id`
- `support_required`
- `student_facing_summary`
- `review_date`
- `status`

## Entity 6: Service assignment

- `assignment_id`
- `student_id`
- `assigned_by`
- `title`
- `purpose`
- `linked_competencies`
- `instructions`
- `authority_boundary`
- `support_person`
- `assigned_date`
- `due_date`
- `outcome`
- `initiative_observed`
- `dependability_observed`
- `teamwork_observed`
- `lessons_learned`
- `mentor_feedback`
- `status`

## Entity 7: Preaching relationship

- `relationship_id`
- `caretaker_student_id`
- `newcomer_or_junior_id`
- `responsible_guide_id`
- `relationship_stage`
- `first_contact_date`
- `last_contact_date`
- `programs_attended`
- `current_needs_summary`
- `next_step`
- `next_follow_up_date`
- `guide_connection_status`
- `senior_attention_required`
- `active_status`

Avoid storing unnecessary intimate information about newcomers. Record only what is relevant to appropriate care and follow-up.

## Entity 8: Event or trip

- `event_id`
- `name`
- `event_type`
- `purpose`
- `date_range`
- `responsible_guide_id`
- `student_lead_ids`
- `planning_status`
- `budget_status`
- `permissions_status`
- `transport_status`
- `accommodation_status`
- `publicity_status`
- `volunteer_status`
- `participant_welfare_status`
- `post_event_review`

## Entity 9: Contextual summary

- `summary_id`
- `student_id`
- `period_start`
- `period_end`
- `generated_at`
- `source_record_ids`
- `verified_facts`
- `observed_patterns`
- `unresolved_questions`
- `suggested_mentor_questions`
- `possible_next_assignments`
- `reviewed_by_guide`
- `review_status`

System-generated contextual summaries must remain proposals until reviewed by the guide.

## Permissions

Suggested roles:

- System administrator
- Senior responsible authority
- Assigned FOLK guide
- Supporting mentor
- Student
- Operational volunteer

Students may receive an approved development summary and agreed actions. They should not automatically receive raw mentor notes, third-party information, inferred risk flags, or confidential records about other people.

Every read and edit of restricted mentoring information should be auditable.
