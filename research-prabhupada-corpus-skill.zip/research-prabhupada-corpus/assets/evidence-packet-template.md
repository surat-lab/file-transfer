# Corpus Evidence Packet

## Research question

## Direct answer

## Evidence

| Proposition | Source and locator | Authority / speaker | Context and scope | Confidence |
|---|---|---|---|---|

## Corpus-supported synthesis

## Counter-evidence, qualifications, or contextual differences

## Interpretive boundary

## Corpus coverage and search limitations
