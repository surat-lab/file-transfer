# Research Modes and Query Design

## Exact lookup

Use when the user supplies wording, a citation, date, recipient, event, or work. Search distinctive phrases first, then spelling/diacritic variants. Verify the complete chunk and source entry. Report whether the wording is exact, approximate, misattributed, incomplete, or absent.

## Claim verification

Translate the claim into testable components. Search evidence for and against each component. Check attribution, scope, chronology, and whether the claim combines passages from different contexts. Return `supported`, `partially supported`, `unsupported in supplied corpus`, or `contradicted/qualified`, with reasons.

## Thematic synthesis

Construct a concept map before searching:

- central idea;
- synonyms and ordinary-language variants;
- Sanskrit/Bengali terms and spelling variants;
- related practices, actors, obstacles, results, analogies, and scriptural references;
- counter-concepts and limiting terms.

Use metadata to locate candidate clusters, then search the text. Sample all relevant verticals. Group evidence by proposition rather than by source type.

## Comparative research

Define the comparison dimensions in advance: doctrine, audience, historical period, genre, instruction scope, wording, practice, or application. Compare like with like and explain genre differences. A book's doctrinal exposition, a personal letter, and an event-specific conversation do not carry identical scope.

## Chronological research

Search normalized dates, archive IDs, event codes, and year ranges. Do not infer doctrinal development merely from wording differences. Account for audience, question, transcription certainty, and missing incoming correspondence. Distinguish change, clarification, repetition, and context shift.

## Contextual explanation

Retrieve the passage, the preceding question/reading, and the following clarification. For correspondence, inspect thread and missing-context fields. Explain what the statement addresses, what it does not address, and how far it can be generalized.

## Reading guide or source map

Select sources by authority, directness, coverage, and pedagogical sequence. Explain why each source is included. Do not use tag frequency alone to imply importance.

## Exploratory discovery

Begin broad, then iteratively refine terms from actual corpus vocabulary. Preserve surprising or disconfirming findings. End with a map of established themes, weak leads, gaps, and promising next questions rather than premature certainty.

## Search sequence

For substantial research, normally run:

1. exact phrase or proper-noun searches;
2. concept synonyms joined with `OR`;
3. metadata/tag-filtered searches;
4. source-type-specific searches;
5. context, audience, date, recipient, or event filters;
6. counter-evidence and limiting-term searches;
7. citation-alias searches;
8. inspection of selected chunks and neighbours.

Do not confuse search saturation with evidentiary saturation. Stop when additional formulations no longer change the propositions, qualifications, or source coverage—not merely when results repeat.
