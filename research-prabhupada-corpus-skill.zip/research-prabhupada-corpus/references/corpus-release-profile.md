# Corpus Release Profile

## Canonical indexed packages

The skill uses three read-only NotebookLM-ready ZIP packages backed up in OneDrive. Two independent OneDrive copies of each package were hash-compared and matched on 2026-08-09.

| Vertical | Package | ZIP entries | Indexed content | SHA-256 |
|---|---|---:|---|---|
| Books | `Prabhupada_Books_NotebookLM_237_MD.zip` | 237 Markdown files | 237 book/range sources | `60FA79DE65A7038BDB5870ED5A42405492069875CC92821B72E214060558A458` |
| Correspondence | `SP_Correspondence_NotebookLM_250_MD.zip` | 250 Markdown files | 6,572 canonical records | `B5EAC48387B2EDA7EA184BED220736097537674A5B585DCFAD82B8989E6BDAE3` |
| Audio/transcripts | `Srila_Prabhupada_Audio_Transcripts_NotebookLM_250_Protocol_Embedded.zip` | 250 Markdown files | 240 transcript sources representing 3,222 natural events; 10 control files excluded from the full-text index | `7DC751FAC332436EC00DCFCFCD702210F7E98122BC064AB45C142D46B791D6E3` |

Use `assets/corpus_sources.json` as the machine-readable path and hash registry. Do not index the original RTF collections or intermediate pipeline stages when these final packages are available.

## Books metadata

Each source begins with YAML front matter. Common fields include:

- `schema_version`, `title`, `work`, `source_file`, `source_sha256`, `source_span`;
- `source_type`, `authority_layer`, `edition_status`, `language_profile`;
- `conversion_policy`, `integrity_status`, `pass_status`;
- `document_tags`, citation-display and metadata-position policies.

Retrieval units contain visible citation headings and compact `Search metadata` lines with semantic tags, authority, aliases, persons, places, scriptures, and retrieval intents.

Release QA reported 237 sources, 18 Bhagavad Gita chapters, 700 Gita references, 62 Caitanya-caritamrta chapters, 335 Srimad-Bhagavatam chapters, 25,015 canonical reference units, and 75,618 search-metadata units. Disciple-completed Bhagavatam material is explicitly distinguished.

The current ZIP postdates the preserved final report and has a different SHA-256 from the report's earlier value. Both current OneDrive backups match each other exactly; the configured current hash is therefore the operational identity. Do not cite the earlier report hash as the current package hash.

## Correspondence metadata

Each Markdown source groups several correspondence records. The file-level fenced YAML contains source number, date range, document count, and principal tags. Each record has a fenced YAML block followed by smooth correspondence text.

Important record fields include:

- stable `document_id`, canonical title, archive ID, written and normalized dates;
- writer, speaker/dictator, typist/transcriber, signatory, approver;
- `directive_authority`, `authorship_status`, `voice_authority`, attribution confidence;
- recipient, role, location, correspondence direction, document form;
- thread and context-cluster IDs, reply links, missing-context flag and evidence;
- instruction scope, sensitivity, people/organizations/places/projects;
- semantic tags and full-text SHA-256.

Package QA reported 6,572 unique canonical records, four verified duplicate copies excluded, and one empty archival placeholder excluded. Missing incoming letters are explicit missing nodes; never infer their contents.

## Audio/transcript metadata

The protocol-embedded release has 10 `000_` control/index files and 240 transcript sources. Each transcript begins with YAML front matter containing source identity, source RTF hash, part count, event count/range, conversion stage, semantic-tag status, dominant tags, and persistent attribution/context/uncertainty policies.

Natural events include event code, date/place, event type, normalized references, principal speakers, semantic tags, instruction scope, and transcript-certainty notes. Smooth dialogue preserves speaker labels and uncertain wording.

QA reported 3,222 natural events, 12 source-level tags, 3-8 event-level tags, zero transcript-content mismatches after metadata removal, and zero structural/encoding problems.

## Corpus limitations

- These packages represent the supplied source corpus, not every possible edition or archival item.
- Some book files are marked `edition_unverified` or carry other authority/integrity qualifications.
- Correspondence may lack the incoming message being answered.
- Audio transcripts may contain indistinct wording, uncertain speakers, readings, quotations, or other participants.
- Metadata is generated research infrastructure. It routes retrieval but cannot establish a doctrinal or historical claim without text inspection.
- Absence from the index means only that no sufficiently clear evidence was found in these supplied packages and search formulations.
