# Evidence and Attribution Rules

## Source text versus retrieval aids

Treat smooth source text as evidence. Treat titles, semantic tags, normalized entities, context graphs, generated summaries, source indexes, NotebookLM outputs, and search ranks as retrieval aids. A tag hit must lead to a text inspection before it can support an answer.

## Books

Distinguish:

- Prabhupada's prose;
- Sanskrit/Bengali root text;
- Prabhupada translation;
- Prabhupada purport;
- cited earlier acaryas or scripture;
- editor/foreword material;
- disciple-completed or retold material;
- text whose edition status remains unverified.

Never attribute a root verse, quoted authority, publisher heading, or disciple-completed passage as Prabhupada's own prose without qualification. Use the visible work and reference heading as the locator.

## Correspondence

Use document-level authority fields. Secretarial typing does not automatically mean secretary authorship, but mixed files also cannot receive blanket Prabhupada authority.

Distinguish direct correspondence, dictated/transcribed correspondence, approved/relayed instructions, independently authored material, incoming or third-party correspondence, legal/institutional records, enclosures, drafts, and uncertain documents.

Respect `context_scope_note`, `missing_context`, recipient, date, location, thread evidence, and sensitivity. A personal response may illuminate a principle but does not become a universal instruction without broader corroboration.

## Audio and transcripts

Attribute words to Prabhupada only when the transcript explicitly identifies him. Distinguish:

- his direct speech;
- questions and interviewer statements;
- disciple readings or translations;
- quoted scripture or another person's view;
- humour, irony, rhetorical question, analogy, and hypothetical example;
- objections and refutations;
- unclear speaker identification and `[indistinct]` wording.

Preserve event code, date, place, audience, immediate subject, speech function, instruction scope, and transcript certainty when material to meaning.

## Evidence strength

Use these labels:

- **Direct**: clear text directly answers the question with secure authority and attribution.
- **Strong**: several clear passages support the synthesis with compatible contexts.
- **Moderate**: relevant evidence supports a bounded inference but does not state the full conclusion directly.
- **Weak**: indirect, context-limited, incomplete, or attribution-sensitive evidence; normally report as a lead or uncertainty.
- **None found**: no sufficiently clear evidence after adequate searches.

Do not increase confidence merely because a passage is emotionally compelling or because metadata tags recur.

## Scope and generalization test

Before generalizing, ask:

1. Who was speaking or writing?
2. To whom?
3. When and where?
4. What immediate problem or question was being addressed?
5. Is the wording descriptive, prescriptive, rhetorical, quoted, contested, or hypothetical?
6. Is the instruction individual, local, institutional, movement-wide, or doctrinal?
7. Does an independent book passage or separate event support the broader formulation?
8. What exception, qualification, or missing context could change the interpretation?

If these cannot be answered, narrow the claim.
