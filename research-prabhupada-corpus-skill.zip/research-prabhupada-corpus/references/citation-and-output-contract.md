# Citation and Output Contract

## Reproducible citation

Every material finding should identify enough information to retrieve it again.

### Books

Prefer:

`Full work title + exact chapter/verse/section + Translation/Purport/Prose`

Examples: `Bhagavad Gita As It Is 6.35 — Purport`; `Beyond Birth and Death, Chapter 1`.

Also preserve the ZIP entry name and indexed chunk ID in technical evidence packets when useful.

### Correspondence

Prefer:

`Canonical title — normalized date — document ID`

Add recipient, location, authorship/authority status, and missing-context qualification when material.

### Audio/transcripts

Prefer:

`Event title/type — date and place — event code — speaker`

Add source ZIP entry, transcript certainty, and immediate question/reading when material. The prepared transcript corpus does not guarantee playable-audio timestamps; never invent them.

## Quotation handling

- Verify exact wording with `verify` and inspect the source unit.
- Quote only the portion needed to establish the point.
- Preserve ellipses, uncertain wording, and speaker boundaries honestly.
- Never repair grammar or transcription silently inside quotation marks.
- Use a faithful paraphrase when a long quotation is unnecessary; label it as paraphrase.

## Default answer structure

Adapt length to the question, but preserve this logic:

1. **Direct answer** — conclusion and confidence.
2. **Strongest evidence** — proposition-linked sources.
3. **Context and scope** — audience, genre, situation, authority, and limits.
4. **Synthesis** — explicitly distinguish direct teaching from inference.
5. **Qualifications or counter-evidence**.
6. **Corpus coverage statement** when the search was limited or evidence was absent.

For large research tasks, use `assets/evidence-packet-template.md`.

## Downstream handoff

When another project requests evidence, return records with:

- `proposition`;
- `source_vertical`;
- `source_title` and stable locator;
- `archive_entry` and `chunk_id`;
- `authority_or_speaker`;
- `context_and_scope`;
- `evidence_strength`;
- `source_supported_text_or_paraphrase`;
- `interpretive_boundary`;
- `verification_status`.

Do not write the downstream project's conclusion on its behalf. Supply evidence and clearly labelled possible applications.
