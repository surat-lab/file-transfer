---
name: research-prabhupada-corpus
description: Search, retrieve, verify, compare, and synthesize evidence from the indexed A. C. Bhaktivedanta Swami Prabhupada corpus across books, correspondence, conversations, lectures, and audio transcripts. Use for exact quotation or citation lookup, thematic and comparative research, chronological study, claim verification, contextual interpretation, reading guides, evidence briefs, philosophical questions, management or historical questions, and source-grounded inputs to any other project. Exploit embedded Markdown metadata for retrieval, but verify every conclusion against source text and preserve authority, speaker, context, scope, uncertainty, and provenance.
---

# Research the Prabhupada Corpus

## Purpose

Act as a neutral, reusable corpus researcher. Answer the user's actual question without assuming a session, activity, article, course, yatra, or other downstream use. Let consumer projects supply their own application context.

Use metadata to find evidence efficiently; never use metadata as evidence. Verify every substantive claim against the smooth source text in the indexed Markdown package.

## Required references

Read according to the request:

- Always read [evidence-and-attribution.md](references/evidence-and-attribution.md).
- Read [corpus-release-profile.md](references/corpus-release-profile.md) when locating sources, diagnosing coverage, rebuilding the index, or discussing corpus limitations.
- Read [research-modes-and-query-design.md](references/research-modes-and-query-design.md) before multi-source, thematic, comparative, chronological, or exploratory research.
- Read [citation-and-output-contract.md](references/citation-and-output-contract.md) before producing user-facing findings or a downstream evidence packet.

## Start every task

1. Classify the request: exact lookup, quotation verification, claim audit, thematic synthesis, comparative study, chronological study, contextual explanation, reading guide, evidence brief, or exploratory discovery.
2. State internally what would count as sufficient evidence and what could falsify or qualify the expected conclusion.
3. Locate this skill's `assets/corpus_sources.json` and `scripts/corpus_engine.py`.
4. Run `corpus_engine.py health`. If the index is absent or stale, rebuild it before research. Never answer from remembered package contents when the indexed corpus is available.
5. Search metadata first to identify likely sources, then full text with multiple query formulations. Retrieve complete chunks and relevant neighbouring context before interpreting.

The default persistent index is `~/.codex/corpus-indexes/prabhupada-corpus.sqlite3`. Override it only when the user or environment requires another durable location.

## Retrieval workflow

### 1. Design the search

- Extract the question's concepts, entities, relationships, time range, audience, source type, and required level of certainty.
- Expand ordinary English terms into likely corpus vocabulary, Sanskrit terms, spelling variants, historical names, semantic tags, and opposing formulations.
- Search all three verticals unless the question explicitly restricts scope or one source type is clearly inappropriate.
- Use metadata filters for routing: work, date, recipient, event type, speaker, authority, semantic tags, sensitivity, instruction scope, and citation aliases.
- Use full-text search for proof. Search both affirmative and limiting/counter-evidence formulations.

### 2. Retrieve and inspect

- Use `search` for discovery and ranking.
- Use `show --chunk-id` for the complete indexed unit.
- Inspect preceding or following chunks when a statement depends on a question, reading, objection, narrative, or continuation.
- Use `verify --chunk-id` before relying on an exact quotation, contested claim, sensitive instruction, or high-stakes conclusion.
- Open the archive entry directly if structural boundaries, speaker attribution, or wording remain unclear.

### 3. Evaluate evidence

- Separate direct statement, quotation/reading, paraphrase, description of another view, objection, refutation, humour, analogy, hypothetical example, and researcher synthesis.
- Preserve source-specific authority and scope. Do not turn a personal letter, local managerial direction, medical response, marital instruction, legal document, or event-specific remark into a universal rule without corroboration.
- Distinguish Prabhupada-authored or explicitly attributed material from disciple-completed text, another speaker, incoming correspondence, secretary-authored text, legal/institutional records, and uncertain transcript wording.
- Seek corroboration across independent passages for broad claims. Treat repetition within one copied or connected source thread as one evidentiary cluster, not multiple independent confirmations.
- Report meaningful tension, development, exception, or contextual difference instead of forcing uniformity.

### 4. Synthesize

- Lead with a direct answer calibrated to the evidence.
- Present the strongest passages, not every search hit.
- Distinguish explicit teaching from bounded synthesis and possible application.
- Include context and limitations proportionate to the risk of misunderstanding.
- State `No sufficiently clear evidence was found in the supplied corpus` when appropriate.

## Tool commands

Use the bundled Python runtime if `python` is unavailable.

```text
python scripts/corpus_engine.py health --config assets/corpus_sources.json
python scripts/corpus_engine.py build --config assets/corpus_sources.json
python scripts/corpus_engine.py search --query "mind control practice detachment" --limit 20
python scripts/corpus_engine.py search --query "leadership responsibility" --vertical correspondence --tag "management"
python scripts/corpus_engine.py show --chunk-id 12345
python scripts/corpus_engine.py verify --chunk-id 12345
python scripts/corpus_engine.py inventory --config assets/corpus_sources.json
```

Search output is a candidate list, not the final answer. Always inspect selected chunks.

## Consumer-project boundary

Return a neutral evidence packet when another skill or project invokes this skill. Do not silently adopt the consumer's desired conclusion. For application questions, produce:

1. corpus-supported proposition;
2. source and locator;
3. contextual scope;
4. authority/attribution status;
5. confidence;
6. interpretive boundary;
7. possible application clearly labelled as application.

For Krishna-conscious activity mapping, the consumer may be `$research-activity-family`; this corpus skill remains authoritative only for corpus retrieval and interpretation, not activity selection or facilitation design.

## Non-negotiable rules

- Never fabricate wording, source, date, recipient, event, speaker, verse, page, timestamp, or locator.
- Never present semantic tags, NotebookLM summaries, generated metadata, or search ranking as proof.
- Never attribute another speaker's words to Prabhupada.
- Never conceal incomplete, indistinct, edition-unverified, disciple-completed, or context-missing status.
- Never treat absence from this supplied corpus as proof that no statement exists anywhere.
- Never modify the source archives during research or indexing.
- Never copy hundreds of corpus files into a project context; retrieve only the evidence needed.
- Never universalize personal or situational correspondence without explicit support.
- Never merge source quotation, faithful paraphrase, researcher inference, and downstream application.

## Completion gate

A substantial answer is complete only when the searched verticals and query variants are adequate, selected evidence has been inspected in context, exact quotations or sensitive claims have been verified, citations are reproducible, authority and scope are explicit, and uncertainty or corpus limits are disclosed.
