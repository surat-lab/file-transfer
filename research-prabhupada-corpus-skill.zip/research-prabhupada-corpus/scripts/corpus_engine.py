#!/usr/bin/env python3
"""Build and query a provenance-preserving index over the prepared corpus ZIPs."""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import re
import shlex
import sqlite3
import sys
import zipfile
from pathlib import Path


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")


SKILL_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG = SKILL_ROOT / "assets" / "corpus_sources.json"
DEFAULT_DB = Path.home() / ".codex" / "corpus-indexes" / "prabhupada-corpus.sqlite3"
MAX_CHARS = 9000
OVERLAP_LINES = 3


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def load_config(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def config_hash(config: dict) -> str:
    payload = json.dumps(config, sort_keys=True, ensure_ascii=False).encode("utf-8")
    return sha256_bytes(payload)


def connect_readonly(db_path: Path) -> sqlite3.Connection:
    """Open a stable installed index without requesting directory write access."""
    uri = db_path.resolve().as_uri() + "?mode=ro&immutable=1"
    return sqlite3.connect(uri, uri=True)


def locate_archive(source: dict, verify_hash: bool = True) -> Path:
    mismatches = []
    for raw in source.get("candidate_paths", []):
        path = Path(raw)
        if not path.is_file():
            continue
        if verify_hash:
            actual = sha256_file(path)
            if actual != source["sha256"].upper():
                mismatches.append(f"{path} ({actual})")
                continue
        return path
    detail = f" Hash mismatches: {'; '.join(mismatches)}" if mismatches else ""
    raise FileNotFoundError(f"No valid archive found for {source['key']}.{detail}")


def decode_markdown(data: bytes) -> str:
    return data.decode("utf-8-sig", errors="replace").replace("\r\n", "\n").replace("\r", "\n")


def scalar(text: str, key: str) -> str:
    pattern = rf"(?mi)^[ \t]*{re.escape(key)}:[ \t]*(.+?)[ \t]*$"
    match = re.search(pattern, text)
    if not match:
        return ""
    value = match.group(1).strip()
    if value.startswith('"') and value.endswith('"'):
        value = value[1:-1]
    return value


def list_values(text: str, keys: list[str]) -> list[str]:
    values = []
    for key in keys:
        inline = re.search(rf"(?mi)^[ \t]*{re.escape(key)}:[ \t]*\[(.*?)\][ \t]*$", text)
        if inline:
            values.extend(re.findall(r'["\']([^"\']+)["\']', inline.group(1)))
        block = re.search(
            rf"(?ms)^[ \t]*{re.escape(key)}:[ \t]*\n((?:[ \t]+-[ \t]+.*\n?)+)", text
        )
        if block:
            values.extend(re.findall(r'(?m)^[ \t]+-[ \t]+["\']?(.+?)["\']?[ \t]*$', block.group(1)))
    for metadata_line in re.findall(r"(?mi)^> Search metadata[^\n]*$", text):
        tag_part = re.search(r"semantic-tags:[ \t]*([^;|]+)", metadata_line, re.I)
        if tag_part:
            values.extend(x.strip(" `") for x in tag_part.group(1).split(","))
        for field in ("persons", "places", "scriptures", "retrieval-intents", "primary-reference-aliases"):
            part = re.search(rf"{field}:[ \t]*([^;|]+)", metadata_line, re.I)
            if part:
                values.extend(x.strip(" `") for x in part.group(1).split(","))
    cleaned = []
    seen = set()
    for value in values:
        value = value.strip().strip('"\'')
        if value and value not in seen:
            cleaned.append(value)
            seen.add(value)
    return cleaned


def top_frontmatter(text: str) -> str:
    if not text.startswith("---\n"):
        return ""
    end = text.find("\n---\n", 4)
    return text[4:end] if end >= 0 else ""


def line_number(text: str, offset: int) -> int:
    return text.count("\n", 0, offset) + 1


def heading_sections(text: str, levels: str = "23"):
    minimum = min(int(level) for level in levels)
    maximum = max(int(level) for level in levels)
    quantifier = f"{{{minimum}}}" if minimum == maximum else f"{{{minimum},{maximum}}}"
    matches = list(re.finditer(rf"(?m)^(#{quantifier})[ \t]+(.+?)[ \t]*$", text))
    sections = []
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        segment = text[match.start():end].strip()
        if len(segment) >= 80:
            sections.append((match.group(2).strip(), segment, match.start(), end))
    return sections


def split_long(title: str, content: str, start: int, full_text: str):
    if len(content) <= MAX_CHARS:
        return [(title, content, line_number(full_text, start), line_number(full_text, start + len(content)))]
    lines = content.splitlines()
    output, current, current_chars, relative_start = [], [], 0, 0
    line_cursor = line_number(full_text, start)
    unit_start_line = line_cursor
    for line in lines:
        size = len(line) + 1
        if current and current_chars + size > MAX_CHARS:
            output.append((title, "\n".join(current).strip(), unit_start_line, line_cursor - 1))
            overlap = current[-OVERLAP_LINES:]
            current = overlap[:]
            current_chars = sum(len(x) + 1 for x in current)
            unit_start_line = max(unit_start_line, line_cursor - len(overlap))
        current.append(line)
        current_chars += size
        line_cursor += 1
        relative_start += size
    if current:
        output.append((title, "\n".join(current).strip(), unit_start_line, line_cursor - 1))
    return [item for item in output if item[1]]


def split_entry(vertical: str, entry_name: str, text: str):
    front = top_frontmatter(text)
    source_title = scalar(front, "title") or scalar(front, "work") or Path(entry_name).stem
    raw_sections = []
    if vertical == "correspondence":
        for title, segment, start, end in heading_sections(text, "2"):
            if scalar(segment, "document_id"):
                raw_sections.append((title, segment, start, end))
    elif vertical == "audio":
        for title, segment, start, end in heading_sections(text, "2"):
            if re.search(r"(?mi)^\*\*Event code:\*\*", segment):
                raw_sections.append((title, segment, start, end))
    else:
        raw_sections = heading_sections(text, "23")

    if not raw_sections:
        raw_sections = [(source_title, text, 0, len(text))]

    chunks = []
    for title, content, start, _ in raw_sections:
        chunks.extend(split_long(title, content, start, text))
    return source_title, front, chunks


def chunk_metadata(vertical: str, source_title: str, title: str, content: str, entry_name: str) -> dict:
    tags = list_values(content, ["document_tags", "principal_tags", "semantic_tags", "dominant_semantic_tags", "thread_subjects"])
    unit_id = scalar(content, "document_id")
    event = re.search(r"(?mi)^\*\*Event code:\*\*[ \t]*`?([^`\n]+)`?", content)
    if not unit_id and event:
        unit_id = event.group(1).strip()
    locator = title
    if vertical == "correspondence":
        locator = scalar(content, "canonical_title") or title
    date = scalar(content, "normalized_date")
    if not date:
        event_date = re.search(r"(?mi)^\*\*Date and place:\*\*[ \t]*(.+)$", content)
        date = event_date.group(1).strip() if event_date else ""
    authority = " | ".join(filter(None, [
        scalar(content, "authority_layer"), scalar(content, "authorship_status"),
        scalar(content, "voice_authority"), scalar(content, "attribution_confidence")
    ]))
    speaker = scalar(content, "speaker_or_dictator")
    principal = re.search(r"(?mi)^-[ \t]*\*\*Principal speakers:\*\*[ \t]*(.+)$", content)
    if principal:
        speaker = principal.group(1).strip()
    scope = scalar(content, "context_scope_note") or scalar(content, "instruction_scope")
    return {
        "unit_id": unit_id or f"{Path(entry_name).stem}:{title}",
        "title": title,
        "locator": locator,
        "date_context": date,
        "authority": authority,
        "speaker": speaker,
        "scope": scope,
        "tags": tags,
        "source_title": source_title,
    }


def create_schema(connection: sqlite3.Connection):
    connection.executescript(
        """
        PRAGMA journal_mode=WAL;
        PRAGMA synchronous=NORMAL;
        CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE sources (
            id INTEGER PRIMARY KEY,
            archive_key TEXT NOT NULL,
            vertical TEXT NOT NULL,
            archive_path TEXT NOT NULL,
            archive_sha256 TEXT NOT NULL,
            entry_name TEXT NOT NULL,
            entry_sha256 TEXT NOT NULL,
            source_title TEXT,
            frontmatter TEXT,
            chars INTEGER NOT NULL,
            lines INTEGER NOT NULL,
            UNIQUE(archive_key, entry_name)
        );
        CREATE TABLE chunks (
            id INTEGER PRIMARY KEY,
            source_id INTEGER NOT NULL REFERENCES sources(id),
            sequence_in_source INTEGER NOT NULL,
            vertical TEXT NOT NULL,
            unit_id TEXT,
            title TEXT,
            locator TEXT,
            date_context TEXT,
            authority TEXT,
            speaker TEXT,
            scope TEXT,
            tags TEXT,
            start_line INTEGER,
            end_line INTEGER,
            content TEXT NOT NULL
        );
        CREATE INDEX idx_chunks_vertical ON chunks(vertical);
        CREATE INDEX idx_chunks_source ON chunks(source_id, sequence_in_source);
        CREATE INDEX idx_chunks_unit ON chunks(unit_id);
        CREATE VIRTUAL TABLE chunks_fts USING fts5(
            content, title, tags, locator,
            content='chunks', content_rowid='id',
            tokenize='unicode61 remove_diacritics 2'
        );
        """
    )


def build_index(config_path: Path, db_path: Path):
    config = load_config(config_path)
    db_path = db_path.resolve()
    db_path.parent.mkdir(parents=True, exist_ok=True)
    building = db_path.with_name(db_path.name + ".building")
    if building.exists():
        building.unlink()
    connection = sqlite3.connect(building)
    create_schema(connection)
    connection.execute("INSERT INTO metadata VALUES (?, ?)", ("config_sha256", config_hash(config)))
    connection.execute("INSERT INTO metadata VALUES (?, ?)", ("built_at", dt.datetime.now().astimezone().isoformat()))
    connection.execute("INSERT INTO metadata VALUES (?, ?)", ("engine_version", "1.0"))

    source_count = chunk_count = 0
    vertical_counts = {}
    for source in config["sources"]:
        archive = locate_archive(source, verify_hash=True)
        include = re.compile(source.get("entry_include_regex", r".*\.md$"), re.I)
        with zipfile.ZipFile(archive) as bundle:
            if bundle.testzip():
                raise RuntimeError(f"ZIP integrity error: {archive}")
            entries = [entry for entry in bundle.infolist() if not entry.is_dir() and include.search(entry.filename)]
            for entry in entries:
                data = bundle.read(entry)
                text = decode_markdown(data)
                source_title, front, chunks = split_entry(source["vertical"], entry.filename, text)
                cursor = connection.execute(
                    """INSERT INTO sources
                    (archive_key, vertical, archive_path, archive_sha256, entry_name, entry_sha256,
                     source_title, frontmatter, chars, lines)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (source["key"], source["vertical"], str(archive), source["sha256"].upper(),
                     entry.filename, sha256_bytes(data), source_title, front, len(text), text.count("\n") + 1),
                )
                source_id = cursor.lastrowid
                source_count += 1
                for sequence, (title, content, start_line, end_line) in enumerate(chunks, 1):
                    meta = chunk_metadata(source["vertical"], source_title, title, content, entry.filename)
                    connection.execute(
                        """INSERT INTO chunks
                        (source_id, sequence_in_source, vertical, unit_id, title, locator, date_context,
                         authority, speaker, scope, tags, start_line, end_line, content)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                        (source_id, sequence, source["vertical"], meta["unit_id"], meta["title"],
                         meta["locator"], meta["date_context"], meta["authority"], meta["speaker"],
                         meta["scope"], " | ".join(meta["tags"]), start_line, end_line, content),
                    )
                    chunk_count += 1
                    vertical_counts[source["vertical"]] = vertical_counts.get(source["vertical"], 0) + 1
            connection.commit()
    connection.execute("INSERT INTO chunks_fts(chunks_fts) VALUES('rebuild')")
    connection.execute("INSERT INTO metadata VALUES (?, ?)", ("source_count", str(source_count)))
    connection.execute("INSERT INTO metadata VALUES (?, ?)", ("chunk_count", str(chunk_count)))
    connection.commit()
    connection.close()

    backup = db_path.with_name(db_path.name + ".previous")
    if db_path.exists():
        if backup.exists():
            backup.unlink()
        db_path.replace(backup)
    building.replace(db_path)
    result = {"status": "PASS", "database": str(db_path), "sources": source_count, "chunks": chunk_count, "by_vertical": vertical_counts}
    print(json.dumps(result, ensure_ascii=False, indent=2))


def make_match(query: str, mode: str) -> str:
    terms = shlex.split(query)
    safe = []
    for term in terms:
        term = term.replace('"', '""').strip()
        if term:
            safe.append(f'"{term}"')
    if not safe:
        raise ValueError("Search query contains no usable terms.")
    joiner = " AND " if mode == "all" else " OR "
    return joiner.join(safe)


def search(db_path: Path, query: str, vertical: str | None, tag: str | None, limit: int, mode: str, as_json: bool):
    connection = connect_readonly(db_path)
    connection.row_factory = sqlite3.Row
    conditions = ["chunks_fts MATCH ?"]
    parameters = [make_match(query, mode)]
    if vertical:
        conditions.append("c.vertical = ?")
        parameters.append(vertical)
    if tag:
        conditions.append("c.tags LIKE ?")
        parameters.append(f"%{tag}%")
    parameters.append(limit)
    sql = f"""
        SELECT c.id AS chunk_id, c.vertical, s.source_title, s.entry_name, c.unit_id,
               c.locator, c.date_context, c.authority, c.speaker, c.scope, c.tags,
               c.start_line, c.end_line,
               bm25(chunks_fts, 1.0, 3.0, 2.2, 2.5) AS rank,
               snippet(chunks_fts, 0, '[', ']', ' … ', 36) AS snippet
        FROM chunks_fts
        JOIN chunks c ON c.id = chunks_fts.rowid
        JOIN sources s ON s.id = c.source_id
        WHERE {' AND '.join(conditions)}
        ORDER BY rank
        LIMIT ?
    """
    rows = [dict(row) for row in connection.execute(sql, parameters)]
    connection.close()
    if as_json:
        print(json.dumps(rows, ensure_ascii=False, indent=2))
        return
    for row in rows:
        print(f"\n[{row['chunk_id']}] {row['vertical']} | {row['locator']} | {row['date_context']}")
        print(f"Source: {row['source_title']} :: {row['entry_name']} lines {row['start_line']}-{row['end_line']}")
        if row["speaker"] or row["authority"] or row["scope"]:
            print(f"Authority/speaker/scope: {row['authority']} | {row['speaker']} | {row['scope']}")
        if row["tags"]:
            print(f"Tags: {row['tags'][:500]}")
        print(row["snippet"])


def show(db_path: Path, chunk_id: int, neighbours: int):
    connection = connect_readonly(db_path)
    connection.row_factory = sqlite3.Row
    target = connection.execute("SELECT * FROM chunks WHERE id = ?", (chunk_id,)).fetchone()
    if not target:
        raise SystemExit(f"Unknown chunk ID: {chunk_id}")
    rows = connection.execute(
        """SELECT c.*, s.archive_key, s.archive_path, s.entry_name, s.entry_sha256, s.source_title
           FROM chunks c JOIN sources s ON s.id = c.source_id
           WHERE c.source_id = ? AND c.sequence_in_source BETWEEN ? AND ?
           ORDER BY c.sequence_in_source""",
        (target["source_id"], max(1, target["sequence_in_source"] - neighbours), target["sequence_in_source"] + neighbours),
    ).fetchall()
    for row in rows:
        metadata = {key: row[key] for key in row.keys() if key != "content"}
        print("\n" + "=" * 80)
        print(json.dumps(metadata, ensure_ascii=False, indent=2))
        print("-" * 80)
        print(row["content"])
    connection.close()


def verify_chunk(db_path: Path, chunk_id: int):
    connection = connect_readonly(db_path)
    connection.row_factory = sqlite3.Row
    row = connection.execute(
        """SELECT c.content, c.start_line, c.end_line, s.archive_path, s.archive_sha256,
                  s.entry_name, s.entry_sha256
           FROM chunks c JOIN sources s ON s.id = c.source_id WHERE c.id = ?""", (chunk_id,)
    ).fetchone()
    connection.close()
    if not row:
        raise SystemExit(f"Unknown chunk ID: {chunk_id}")
    archive = Path(row["archive_path"])
    archive_ok = sha256_file(archive) == row["archive_sha256"]
    with zipfile.ZipFile(archive) as bundle:
        data = bundle.read(row["entry_name"])
    entry_ok = sha256_bytes(data) == row["entry_sha256"]
    text = decode_markdown(data)
    content_ok = row["content"] in text
    result = {
        "status": "PASS" if archive_ok and entry_ok and content_ok else "FAIL",
        "chunk_id": chunk_id,
        "archive_hash_matches": archive_ok,
        "entry_hash_matches": entry_ok,
        "indexed_content_present_verbatim": content_ok,
        "archive": str(archive),
        "entry": row["entry_name"],
        "lines": f"{row['start_line']}-{row['end_line']}",
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "PASS" else 1


def inventory(config_path: Path):
    config = load_config(config_path)
    report = {"config": str(config_path.resolve()), "sources": []}
    for source in config["sources"]:
        archive = locate_archive(source, verify_hash=True)
        include = re.compile(source.get("entry_include_regex", r".*\.md$"), re.I)
        stats = {"frontmatter": 0, "fenced_yaml": 0, "search_metadata": 0, "persistent_boundary": 0}
        with zipfile.ZipFile(archive) as bundle:
            all_entries = [e for e in bundle.infolist() if not e.is_dir()]
            included = [e for e in all_entries if include.search(e.filename)]
            for entry in included:
                text = decode_markdown(bundle.read(entry))
                stats["frontmatter"] += int(text.startswith("---\n"))
                stats["fenced_yaml"] += int("```yaml" in text)
                stats["search_metadata"] += int("Search metadata" in text)
                stats["persistent_boundary"] += int("Persistent research boundary" in text)
        report["sources"].append({
            "key": source["key"], "vertical": source["vertical"], "archive": str(archive),
            "sha256": sha256_file(archive), "zip_entries": len(all_entries),
            "indexed_entries": len(included), "expected_entries": source["expected_entries"],
            "metadata_presence_by_file": stats,
        })
    print(json.dumps(report, ensure_ascii=False, indent=2))


def health(config_path: Path, db_path: Path, fast: bool):
    config = load_config(config_path)
    checks, ok = [], True
    for source in config["sources"]:
        try:
            archive = locate_archive(source, verify_hash=not fast)
            with zipfile.ZipFile(archive) as bundle:
                count = len([e for e in bundle.infolist() if not e.is_dir()])
                integrity = bundle.testzip() is None
            passed = count == source["expected_entries"] and integrity
            checks.append({"source": source["key"], "status": "PASS" if passed else "FAIL", "entries": count, "archive": str(archive)})
            ok = ok and passed
        except Exception as error:
            checks.append({"source": source["key"], "status": "FAIL", "error": str(error)})
            ok = False
    db_info = {"exists": db_path.is_file(), "path": str(db_path)}
    if db_path.is_file():
        try:
            connection = connect_readonly(db_path)
            meta = dict(connection.execute("SELECT key, value FROM metadata"))
            db_info.update({
                "config_matches": meta.get("config_sha256") == config_hash(config),
                "built_at": meta.get("built_at"),
                "sources": connection.execute("SELECT COUNT(*) FROM sources").fetchone()[0],
                "chunks": connection.execute("SELECT COUNT(*) FROM chunks").fetchone()[0],
                "by_vertical": dict(connection.execute("SELECT vertical, COUNT(*) FROM chunks GROUP BY vertical")),
            })
            connection.close()
            ok = ok and db_info["config_matches"] and db_info["chunks"] > 0
        except Exception as error:
            db_info["error"] = str(error)
            ok = False
    else:
        ok = False
    print(json.dumps({"status": "PASS" if ok else "REBUILD_REQUIRED", "archives": checks, "index": db_info}, ensure_ascii=False, indent=2))
    return 0 if ok else 2


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    for name in ("inventory", "build", "health"):
        command = sub.add_parser(name)
        command.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
        if name in ("build", "health"):
            command.add_argument("--db", type=Path, default=DEFAULT_DB)
        if name == "health":
            command.add_argument("--fast", action="store_true", help="Skip full archive hashing")

    command = sub.add_parser("search")
    command.add_argument("--db", type=Path, default=DEFAULT_DB)
    command.add_argument("--query", required=True)
    command.add_argument("--vertical", choices=["books", "correspondence", "audio"])
    command.add_argument("--tag")
    command.add_argument("--limit", type=int, default=20)
    command.add_argument("--mode", choices=["any", "all"], default="any")
    command.add_argument("--json", action="store_true")

    command = sub.add_parser("show")
    command.add_argument("--db", type=Path, default=DEFAULT_DB)
    command.add_argument("--chunk-id", type=int, required=True)
    command.add_argument("--neighbours", type=int, default=0)

    command = sub.add_parser("verify")
    command.add_argument("--db", type=Path, default=DEFAULT_DB)
    command.add_argument("--chunk-id", type=int, required=True)
    return parser.parse_args()


def main():
    args = parse_args()
    if args.command == "inventory":
        inventory(args.config)
    elif args.command == "build":
        build_index(args.config, args.db)
    elif args.command == "health":
        return health(args.config, args.db, args.fast)
    elif args.command == "search":
        search(args.db, args.query, args.vertical, args.tag, args.limit, args.mode, args.json)
    elif args.command == "show":
        show(args.db, args.chunk_id, args.neighbours)
    elif args.command == "verify":
        return verify_chunk(args.db, args.chunk_id)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (FileNotFoundError, ValueError, sqlite3.Error, zipfile.BadZipFile) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        sys.exit(1)
